import org.junit.Test;

import javax.swing.*;

import static org.junit.Assert.*;

public class SystemUITest {

    @Test
    public void main() {
        SystemUI systemUI = new SystemUI();

        assertNotNull(systemUI);
    }

    @Test
    public void run() {
    }
}